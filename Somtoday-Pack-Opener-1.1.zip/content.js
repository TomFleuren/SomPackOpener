const STORAGE_KEY = "openedPackIds";
const SOURCE = "somtoday-packopener";
const createPackScreen = globalThis.SomtodayPack.createPackScreen;

function pageIsCijfers() {
  const path = location.pathname.replace(/\/+$/, "").toLowerCase();
  return path === "/cijfers" || path.endsWith("/cijfers");
}

const screen = createPackScreen({
  loadOpened: async () => {
    const data = await chrome.storage.local.get(STORAGE_KEY);
    return data[STORAGE_KEY] || [];
  },
  saveOpened: async (ids) => {
    await chrome.storage.local.set({ [STORAGE_KEY]: ids });
  },
  loadArt: async () => {
    const data = await chrome.storage.local.get("packArt");
    return data.packArt || null;
  },
  saveArt: async (art) => {
    await chrome.storage.local.set({ packArt: art });
  },
  resetOpened: async () => {
    await chrome.storage.local.set({
      openedPackIds: [],
      packsResetAt: Date.now(),
    });
  },
});

function announce() {
  window.postMessage({ source: SOURCE, type: "ready" }, "*");
}

screen.setOnCijfers(pageIsCijfers());
announce();
setTimeout(announce, 400);
setTimeout(announce, 1200);

window.addEventListener("message", (event) => {
  const data = event.data;
  if (!data || data.source !== SOURCE || data.type === "ready") return;
  if (data.type === "nav") screen.setOnCijfers(pageIsCijfers());
  if (data.type === "results") screen.addResults(data.endpoint, data.items);
});

setInterval(() => {
  screen.setOnCijfers(pageIsCijfers());
}, 400);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== "ping") return;
  sendResponse({ ok: true, onCijfers: pageIsCijfers() });
});

chrome.storage.local.get("overlayEnabled").then((data) => {
  screen.setEnabled(data.overlayEnabled !== false);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.overlayEnabled) screen.setEnabled(changes.overlayEnabled.newValue !== false);
  if (changes.packsResetAt) {
    const ids = changes.openedPackIds ? changes.openedPackIds.newValue : [];
    screen.applyExternalOpened(ids || []);
    return;
  }
  if (changes.openedPackIds) screen.syncOpened(changes.openedPackIds.newValue || []);
});
