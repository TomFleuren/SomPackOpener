(function () {
  if (window.__somtodayPackopener) return;
  window.__somtodayPackopener = true;

  const SOURCE = "somtoday-packopener";
  const PAGE_SIZE = 30;
  const nativeFetch = window.fetch.bind(window);
  const latest = { voortgang: null, examen: null };
  let contentReady = false;

  function endpointOf(url) {
    const value = String(url || "");
    if (value.includes("geldendvoortgangsdossierresultaten")) return "voortgang";
    if (value.includes("geldendexamendossierresultaten")) return "examen";
    return null;
  }

  function post(message) {
    window.postMessage(Object.assign({ source: SOURCE }, message), "*");
  }

  function postNav() {
    post({ type: "nav", path: location.pathname });
  }

  function publish(endpoint, items) {
    latest[endpoint] = items;
    post({ type: "results", endpoint, items });
  }

  function replay() {
    postNav();
    if (latest.voortgang) post({ type: "results", endpoint: "voortgang", items: latest.voortgang });
    if (latest.examen) post({ type: "results", endpoint: "examen", items: latest.examen });
  }

  window.addEventListener("message", (event) => {
    const data = event.data;
    if (!data || data.source !== SOURCE || data.type !== "ready") return;
    contentReady = true;
    replay();
  });

  function parseRange(header) {
    if (!header) return null;
    const match = String(header).match(/items\s+(\d+)\s*-\s*(\d+)\s*\/\s*(\d+)/i);
    if (!match) return null;
    return { start: Number(match[1]), end: Number(match[2]), total: Number(match[3]) };
  }

  function readItems(data) {
    if (!data || !Array.isArray(data.items)) return [];
    return data.items;
  }

  async function readBody(response) {
    const text = await response.text();
    if (!text) return [];
    try {
      return readItems(JSON.parse(text));
    } catch {
      return [];
    }
  }

  function fetchPage(url, headers, start, end) {
    const nextHeaders = new Headers(headers);
    nextHeaders.set("Range", `items=${start}-${end}`);
    return nativeFetch(url, {
      method: "GET",
      headers: nextHeaders,
      credentials: "include",
      mode: "cors",
    }).catch(() => null);
  }

  async function collectRemaining(url, headers, items, range) {
    let end = range.end;
    let guard = 0;
    while (end + 1 < range.total && guard < 40) {
      guard += 1;
      const start = end + 1;
      const nextEnd = Math.min(start + PAGE_SIZE, range.total - 1);
      const page = await fetchPage(url, headers, start, nextEnd);
      if (!page || page.status >= 400) break;
      const pageItems = await readBody(page);
      items = items.concat(pageItems);
      const pageRange = parseRange(page.headers.get("content-range"));
      const previousEnd = end;
      end = pageRange ? pageRange.end : nextEnd;
      if (!pageItems.length || end <= previousEnd) break;
    }
    return items;
  }

  function handleGradeResponse(url, headers, response) {
    let copy;
    try {
      copy = response.clone();
    } catch {
      return;
    }
    readBody(copy)
      .then(async (items) => {
        const range = parseRange(response.headers.get("content-range"));
        const all =
          range && range.total > 0 && range.end + 1 < range.total
            ? await collectRemaining(url, headers, items, range)
            : items;
        publish(endpointOf(url), all);
      })
      .catch(() => {});
  }

  function installFetch() {
    if (window.fetch && window.fetch.__packopener) return;
    const current = window.fetch.bind(window);
    async function wrapped(input, init) {
      const url = input instanceof Request ? input.url : String(input);
      const endpoint = endpointOf(url);
      const response = await current(input, init);
      if (!endpoint || response.status >= 400) return response;
      const headers = new Headers(input instanceof Request ? input.headers : undefined);
      if (init && init.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
      handleGradeResponse(url, headers, response);
      return response;
    }
    wrapped.__packopener = true;
    window.fetch = wrapped;
  }

  async function handleXhr(xhr, endpoint) {
    if (xhr.status >= 400) return;
    let items = [];
    try {
      const body = xhr.responseType === "" || xhr.responseType === "text" ? xhr.responseText : xhr.response;
      const data = typeof body === "string" ? JSON.parse(body || "null") : body;
      items = readItems(data);
    } catch {
      return;
    }

    let range = null;
    try {
      range = parseRange(xhr.getResponseHeader("content-range"));
    } catch {
      range = null;
    }

    const url = xhr.responseURL || xhr.__packUrl;
    if (range && range.total > 0 && range.end + 1 < range.total) {
      items = await collectRemaining(url, new Headers(xhr.__packHeaders || {}), items, range);
    }
    publish(endpoint, items);
  }

  function installXhr() {
    const proto = XMLHttpRequest.prototype;
    if (!proto.open.__packopener) {
      const open = proto.open;
      function wrappedOpen(method, url) {
        this.__packUrl = url;
        this.__packHeaders = {};
        return open.apply(this, arguments);
      }
      wrappedOpen.__packopener = true;
      proto.open = wrappedOpen;
    }
    if (!proto.setRequestHeader.__packopener) {
      const setHeader = proto.setRequestHeader;
      function wrappedSet(name, value) {
        if (!this.__packHeaders) this.__packHeaders = {};
        this.__packHeaders[name] = value;
        return setHeader.apply(this, arguments);
      }
      wrappedSet.__packopener = true;
      proto.setRequestHeader = wrappedSet;
    }
    if (!proto.send.__packopener) {
      const send = proto.send;
      function wrappedSend() {
        const endpoint = endpointOf(this.__packUrl);
        if (endpoint && !this.__packListening) {
          this.__packListening = true;
          this.addEventListener("load", () => {
            handleXhr(this, endpoint).catch(() => {});
          });
        }
        return send.apply(this, arguments);
      }
      wrappedSend.__packopener = true;
      proto.send = wrappedSend;
    }
  }

  function installHistory() {
    if (history.pushState.__packopener) return;
    const push = history.pushState;
    const replace = history.replaceState;
    function wrappedPush() {
      const result = push.apply(this, arguments);
      postNav();
      return result;
    }
    function wrappedReplace() {
      const result = replace.apply(this, arguments);
      postNav();
      return result;
    }
    wrappedPush.__packopener = true;
    wrappedReplace.__packopener = true;
    history.pushState = wrappedPush;
    history.replaceState = wrappedReplace;
  }

  function install() {
    installFetch();
    installXhr();
    installHistory();
  }

  install();
  let tries = 0;
  const keepAlive = setInterval(() => {
    tries += 1;
    install();
    if (!contentReady) replay();
    if (tries > 30) clearInterval(keepAlive);
  }, 500);

  window.addEventListener("popstate", postNav);
  postNav();
})();
