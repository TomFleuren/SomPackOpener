(() => {
const TYPE_LABELS = {
  Toetskolom: "Toets",
  DeeltoetsKolom: "Deeltoets",
  Werkstukcijferkolom: "Werkstuk",
  Advieskolom: "Advies",
};

const HERKANSING_LABELS = {
  Geen: "Geen herkansing",
  EenKeerHoogste: "1 herkansing, hoogste telt",
  TweeKeerHoogste: "2 herkansingen, hoogste telt",
  EenKeerLaatste: "1 herkansing, laatste telt",
  TweeKeerLaatste: "2 herkansingen, laatste telt",
  EenkeerGemiddeld: "1 herkansing, gemiddelde telt",
  TweeKeerGemiddeld: "2 herkansingen, gemiddelde telt",
};

function clean(value) {
  if (value == null) return "";
  return String(value).trim();
}

function isNumericGrade(value) {
  const text = clean(value).replace(",", ".");
  if (!text) return false;
  return Number.isFinite(Number(text)) && /^-?\d+([.,]\d+)?$/.test(clean(value));
}

function isNee(raw, resultaat) {
  return [raw.label, raw.labelAfkorting, resultaat].some((value) => clean(value).toLowerCase() === "nee");
}

function isFailing(raw, resultaat) {
  return isNee(raw, resultaat) || raw.isVoldoende === false;
}

function gradeNumber(resultaat) {
  if (!isNumericGrade(resultaat)) return null;
  return Number(clean(resultaat).replace(",", "."));
}

function countDelay(shown, target) {
  if (shown < 5.5 || target <= 5.5) return 70;
  const span = Math.max(target - 5.5, 0.1);
  const progress = Math.min(1, (shown - 5.5) / span);
  return 70 + progress * 250;
}

function formatTick(value) {
  return value.toFixed(1).replace(".", ",");
}

function rarityFor(raw, resultaat) {
  if (isFailing(raw, resultaat)) return "label-bad";
  if (raw.isLabel === true || !isNumericGrade(resultaat)) {
    if (raw.isVoldoende === true) return "label-ok";
    return "label";
  }
  const grade = Number(clean(resultaat).replace(",", "."));
  if (grade < 5.5) return "bronze";
  if (grade < 7) return "silver";
  if (grade < 8.5) return "gold";
  return "elite";
}

function formatDatum(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return clean(value);
  return new Intl.DateTimeFormat("nl-NL", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

function formatDatumKort(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (part) => String(part).padStart(2, "0");
  return `${pad(date.getDate())}-${pad(date.getMonth() + 1)}-${date.getFullYear()}`;
}

function formatWeging(value) {
  if (value == null || value === "") return "";
  const number = Number(value);
  if (!Number.isFinite(number)) return clean(value);
  return Number.isInteger(number) ? String(number) : String(value);
}

function normalizeResult(raw) {
  const link = Array.isArray(raw?.links) ? raw.links.find((item) => item.rel === "self") || raw.links[0] : null;
  const id = clean(link?.id);
  if (!id) return null;

  const formatted = clean(raw.formattedResultaat);
  const labelShort = clean(raw.labelAfkorting);
  const label = clean(raw.label);
  let resultaat = formatted || labelShort || label;
  if (!resultaat && raw.cijfer != null && raw.isLabel !== true) resultaat = String(raw.cijfer);
  if (!resultaat) resultaat = "–";

  const extraLabel = label && label !== resultaat ? label : "";

  return {
    id,
    vak: clean(raw.additionalObjects?.vaknaam) || "Onbekend vak",
    resultaat,
    extraLabel,
    omschrijving: clean(raw.omschrijving),
    toetscode: clean(raw.toetscode),
    toetssoort: clean(raw.toetssoort),
    weging: formatWeging(raw.weging),
    periode: raw.periode == null || raw.periode === "" ? "" : String(raw.periode),
    type: TYPE_LABELS[raw.type] || clean(raw.type),
    herkansing: HERKANSING_LABELS[raw.herkansing] || clean(raw.herkansing),
    datum: formatDatum(raw.datumInvoerEerstePoging),
    datumKort: formatDatumKort(raw.datumInvoerEerstePoging),
    isVoldoende: raw.isVoldoende === true ? true : raw.isVoldoende === false ? false : null,
    failing: isFailing(raw, resultaat),
    rarity: rarityFor(raw, resultaat),
  };
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function sameSet(left, right) {
  if (left.size !== right.size) return false;
  for (const value of left) {
    if (!right.has(value)) return false;
  }
  return true;
}

const PACK_FILES = Array.from({ length: 11 }, (_, index) => `pack_${index + 1}.png`);

function shuffle(list) {
  const copy = list.slice();
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(Math.random() * (index + 1));
    const current = copy[index];
    copy[index] = copy[swap];
    copy[swap] = current;
  }
  return copy;
}

function normalizeArt(raw) {
  const order = Array.isArray(raw?.order) && raw.order.length === PACK_FILES.length
    ? raw.order.slice()
    : shuffle(PACK_FILES);
  const byVak = raw?.byVak && typeof raw.byVak === "object" ? { ...raw.byVak } : {};
  let next = Number.isInteger(raw?.next) ? raw.next : 0;
  if (next < 0) next = 0;
  if (next > PACK_FILES.length) next = PACK_FILES.length;
  return { order, byVak, next };
}

function packImageUrl(file) {
  if (globalThis.chrome?.runtime?.getURL) return chrome.runtime.getURL(`packs/${file}`);
  return `packs/${file}`;
}

const FLAG_KEYS = ["nederlands", "engels", "frans", "duits", "spaans", "italiaans", "portugees"];

function flagKey(vak) {
  const name = String(vak || "").trim().toLowerCase();
  return FLAG_KEYS.find((key) => name === key || name.startsWith(`${key} `) || name.startsWith(`${key}-`)) || "";
}

function svgNode(name, attrs) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", name);
  Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
  return node;
}

function flagSvg(key) {
  const svg = svgNode("svg", { class: "stp-flag", viewBox: "0 0 60 40", role: "img" });
  const rect = (attrs) => svg.append(svgNode("rect", attrs));
  if (key === "nederlands") {
    rect({ width: "60", height: "13.34", fill: "#AE1C28" });
    rect({ y: "13.34", width: "60", height: "13.33", fill: "#fff" });
    rect({ y: "26.67", width: "60", height: "13.33", fill: "#21468B" });
  } else if (key === "duits") {
    rect({ width: "60", height: "13.34", fill: "#000" });
    rect({ y: "13.34", width: "60", height: "13.33", fill: "#DD0000" });
    rect({ y: "26.67", width: "60", height: "13.33", fill: "#FFCE00" });
  } else if (key === "frans") {
    rect({ width: "20", height: "40", fill: "#0055A4" });
    rect({ x: "20", width: "20", height: "40", fill: "#fff" });
    rect({ x: "40", width: "20", height: "40", fill: "#EF4135" });
  } else if (key === "italiaans") {
    rect({ width: "20", height: "40", fill: "#009246" });
    rect({ x: "20", width: "20", height: "40", fill: "#fff" });
    rect({ x: "40", width: "20", height: "40", fill: "#CE2B37" });
  } else if (key === "spaans") {
    rect({ width: "60", height: "40", fill: "#C60B1E" });
    rect({ y: "10", width: "60", height: "20", fill: "#FFC400" });
  } else if (key === "portugees") {
    rect({ width: "60", height: "40", fill: "#FF0000" });
    rect({ width: "24", height: "40", fill: "#006600" });
  } else {
    rect({ width: "60", height: "40", fill: "#fff" });
    rect({ x: "25", width: "10", height: "40", fill: "#CF142B" });
    rect({ y: "15", width: "60", height: "10", fill: "#CF142B" });
  }
  return svg;
}

function createPackScreen({ loadOpened, saveOpened, loadArt, saveArt, resetOpened }) {
  let host = null;
  let root = null;
  let groupsEl = null;
  let emptyEl = null;
  let loadingEl = null;
  let countEl = null;
  let stageEl = null;
  let opened = new Set();
  let byEndpoint = { voortgang: null, examen: null };
  let seen = { voortgang: false, examen: false };
  let timedOut = false;
  let loadTimer = null;
  let onCijfers = false;
  let dismissed = false;
  let enabled = true;
  let revealing = false;
  let loaded = false;
  let requestId = 0;
  let timers = [];
  let domHooked = false;
  let packs = [];
  let artState = normalizeArt(null);
  let artReady = false;

  function clearTimers() {
    timers.forEach((id) => clearTimeout(id));
    timers = [];
  }

  function later(fn, ms) {
    const id = setTimeout(fn, ms);
    timers.push(id);
    return id;
  }

  function mergedPacks() {
    const map = new Map();
    for (const endpoint of ["voortgang", "examen"]) {
      const items = byEndpoint[endpoint] || [];
      for (const raw of items) {
        const pack = normalizeResult(raw);
        if (pack) map.set(pack.id, pack);
      }
    }
    return [...map.values()];
  }

  function bothSeen() {
    return timedOut || (seen.voortgang && seen.examen);
  }

  function ensureRoot() {
    if (!document.body) return false;
    const parent = document.body;
    if (!host) {
      host = document.createElement("div");
      host.id = "stp-host";
      host.className = "stp-root";
      root = host;

      const top = el("div", "stp-top");
      const titles = el("div", "stp-titles");
      titles.append(el("p", "stp-kicker", "Somtoday"), el("h1", null, "Packs"));
      countEl = el("p", "stp-count", "");
      titles.append(countEl);
      const dismiss = el("button", "stp-dismiss", "Normale cijfers");
      dismiss.type = "button";
      dismiss.dataset.action = "dismiss";
      const reset = el("button", "stp-reset", "Reset packs");
      reset.type = "button";
      reset.dataset.action = "reset";
      const actions = el("div", "stp-actions");
      actions.append(reset, dismiss);
      top.append(titles, actions);

      groupsEl = el("div", "stp-groups");
      loadingEl = el("p", "stp-message", "Packs laden…");
      emptyEl = el("p", "stp-message", "Geen packs om te openen");
      emptyEl.hidden = true;

      stageEl = el("div", "stp-stage");
      stageEl.hidden = true;

      host.append(top, groupsEl, loadingEl, emptyEl, stageEl);
      host.addEventListener("click", onClick);
    }
    host.style.setProperty("position", "fixed", "important");
    host.style.setProperty("inset", "0", "important");
    host.style.setProperty("z-index", "2147483646", "important");
    if (host.parentElement !== parent) {
      host.style.setProperty("display", "none", "important");
      parent.appendChild(host);
    }
    return true;
  }

  function onClick(event) {
    const packButton = event.target.closest("[data-pack-id]");
    if (packButton) {
      const pack = packs.find((item) => item.id === packButton.dataset.packId);
      if (pack) openPack(pack);
      return;
    }
    if (event.target.closest('[data-action="dismiss"]')) {
      dismissed = true;
      revealing = false;
      clearTimers();
      render();
      return;
    }
    if (event.target.closest('[data-action="reset"]')) {
      if (resetOpened) resetOpened();
      return;
    }
    if (event.target.closest('[data-action="done"]')) finishReveal();
    if (event.target.closest('[data-action="skip"]')) skipReveal();
  }

  function skipReveal() {
    if (!revealing || stageEl.dataset.phase === "details") return;
    clearTimers();
    const grade = stageEl.querySelector('[data-step="grade"]');
    if (grade?.dataset.result) grade.textContent = grade.dataset.result;
    setPhase("details");
  }

  function syncArts(vakNames) {
    if (!artReady) return;
    let changed = false;
    for (const vak of vakNames) {
      if (!vak || artState.byVak[vak]) continue;
      artState.byVak[vak] = artState.next >= PACK_FILES.length ? "pack_1.png" : artState.order[artState.next];
      if (artState.next < PACK_FILES.length) artState.next += 1;
      changed = true;
    }
    if (changed && saveArt) {
      saveArt({
        order: artState.order.slice(),
        byVak: { ...artState.byVak },
        next: artState.next,
      }).catch(() => {});
    }
  }

  function paintPack(pack) {
    const button = el("button", "stp-pack");
    button.type = "button";
    button.dataset.packId = pack.id;
    button.dataset.vak = pack.vak;
    button.setAttribute("aria-label", `Pack openen, ${pack.vak}`);
    const photo = document.createElement("img");
    photo.className = "stp-pack-photo";
    photo.alt = "";
    photo.src = packImageUrl(artState.byVak[pack.vak] || "pack_1.png");
    const released = pack.datumKort ? `Vrijgekomen: ${pack.datumKort}` : "";
    button.append(
      el("span", "stp-pack-vak", pack.vak),
      photo,
      el("span", "stp-pack-date", released),
    );
    return button;
  }

  function paintGrid() {
    syncArts(packs.map((pack) => pack.vak));
    groupsEl.replaceChildren();
    const unopened = packs.filter((pack) => !opened.has(pack.id));
    const waiting = packs.length === 0 && !bothSeen();
    loadingEl.hidden = !waiting;
    emptyEl.hidden = waiting || unopened.length > 0;
    groupsEl.hidden = unopened.length === 0;

    if (waiting) {
      countEl.textContent = "Cijfers ophalen";
      root.dataset.screen = "loading";
      return;
    }
    if (unopened.length === 0) {
      countEl.textContent = "Alles geopend";
      root.dataset.screen = "empty";
      return;
    }

    countEl.textContent =
      unopened.length === 1 ? "1 pack om te openen" : `${unopened.length} packs om te openen`;
    root.dataset.screen = "grid";

    const groups = new Map();
    for (const pack of unopened) {
      if (!groups.has(pack.vak)) groups.set(pack.vak, []);
      groups.get(pack.vak).push(pack);
    }
    const names = [...groups.keys()].sort((a, b) => a.localeCompare(b, "nl"));
    for (const name of names) {
      const section = el("section", "stp-group");
      const heading = el("h2", null, name);
      const row = el("div", "stp-packs");
      for (const pack of groups.get(name)) row.append(paintPack(pack));
      section.append(heading, row);
      groupsEl.append(section);
    }
  }

  function render() {
    if (!loaded) return;
    if (!ensureRoot()) {
      if (!domHooked) {
        domHooked = true;
        document.addEventListener("DOMContentLoaded", () => render(), { once: true });
      }
      return;
    }

    const visible = onCijfers && !dismissed && enabled;
    host.style.setProperty("display", visible ? "flex" : "none", "important");
    root.dataset.screen = visible ? root.dataset.screen : "hidden";
    if (!visible) return;
    if (revealing) return;
    stageEl.hidden = true;
    stageEl.replaceChildren();
    paintGrid();
  }

  function stat(label, value) {
    const row = el("div", "stp-stat");
    row.append(el("span", "stp-stat-label", label), el("span", "stp-stat-value", value));
    return row;
  }

  function setPhase(phase) {
    const previous = stageEl.dataset.phase;
    if (previous && previous !== phase) {
      const prevStep = stageEl.querySelector(`[data-step="${previous}"]`);
      if (prevStep) prevStep.classList.add("is-passed");
    }
    stageEl.dataset.phase = phase;
    stageEl.classList.remove("is-shake", "is-burst", "is-walk", "is-vak", "is-weging", "is-verdict", "is-grade", "is-details");
    stageEl.classList.add("is-moving", `is-${phase}`);
  }

  function buildReveal(pack) {
    const panel = el("div", `stp-reveal stp-rarity-${pack.rarity}`);
    const vak = el("div", "stp-step stp-step-vak");
    vak.dataset.step = "vak";
    const language = flagKey(pack.vak);
    if (language) {
      vak.append(flagSvg(language));
      vak.setAttribute("aria-label", pack.vak);
    } else {
      vak.textContent = pack.vak;
    }
    const weging = el("p", "stp-step stp-step-weging", `Weging: ${pack.weging === "" ? "–" : pack.weging}`);
    weging.dataset.step = "weging";
    const grade = el(
      "p",
      pack.resultaat.length > 4 ? "stp-step stp-step-grade is-long" : "stp-step stp-step-grade",
      pack.resultaat,
    );
    grade.dataset.step = "grade";
    grade.dataset.result = pack.resultaat;
    if (gradeNumber(pack.resultaat) > 1) grade.textContent = "1,0";

    const details = el("div", "stp-step stp-step-details");
    details.dataset.step = "details";
    const card = el("div", "stp-result");
    card.append(
      el("p", "stp-result-vak", pack.vak),
      el("p", pack.resultaat.length > 4 ? "stp-result-grade is-long" : "stp-result-grade", pack.resultaat),
      el("p", "stp-result-meta", `Weging: ${pack.weging === "" ? "–" : pack.weging}`),
    );
    if (pack.extraLabel) card.append(el("p", "stp-extra", pack.extraLabel));
    if (pack.omschrijving) card.append(el("p", "stp-description", pack.omschrijving));
    const stats = el("div", "stp-stats");
    if (pack.periode) stats.append(stat("Periode", pack.periode));
    if (pack.toetscode) stats.append(stat("Toetscode", pack.toetscode));
    if (pack.toetssoort) stats.append(stat("Toetssoort", pack.toetssoort));
    if (pack.type) stats.append(stat("Type", pack.type));
    if (pack.herkansing) stats.append(stat("Herkansing", pack.herkansing));
    if (pack.datum) stats.append(stat("Ingevoerd", pack.datum));
    card.append(stats);
    details.append(card);
    panel.append(vak, weging, grade, details);
    return panel;
  }

  function playCount(gradeEl, pack, done) {
    const target = gradeNumber(pack.resultaat);
    if (target == null || target <= 1) {
      gradeEl.textContent = pack.resultaat;
      later(done, 800);
      return;
    }
    let current = 1;
    const tick = () => {
      current = Math.round((current + 0.1) * 10) / 10;
      if (current >= target - 0.001) {
        gradeEl.textContent = pack.resultaat;
        later(done, 800);
        return;
      }
      gradeEl.textContent = formatTick(current);
      later(tick, countDelay(current, target));
    };
    gradeEl.textContent = formatTick(current);
    later(tick, countDelay(current, target));
  }

  function skipButton() {
    const skip = el("button", "stp-skip", "Overslaan");
    skip.type = "button";
    skip.dataset.action = "skip";
    return skip;
  }

  function buildTunnel() {
    const tunnel = el("div", "stp-tunnel");
    const world = el("div", "stp-tunnel-world");
    for (let index = 0; index < 8; index += 1) {
      const ring = el("div", "stp-ring");
      ring.style.setProperty("--i", String(index));
      ring.append(el("span", "stp-spot is-left"), el("span", "stp-spot is-right"));
      world.append(ring);
    }
    world.append(el("div", "stp-tunnel-floor"));
    const lights = el("div", "stp-floor-lights");
    lights.append(el("span", "stp-beam is-left"), el("span", "stp-beam is-right"));
    tunnel.append(
      el("div", "stp-lattice is-left"),
      el("div", "stp-lattice is-right"),
      world,
      lights,
      el("div", "stp-fog"),
    );
    return tunnel;
  }

  async function openPack(pack) {
    if (revealing || opened.has(pack.id)) return;
    revealing = true;
    opened.add(pack.id);
    try {
      await saveOpened([...opened]);
    } catch {
      opened.delete(pack.id);
      revealing = false;
      return;
    }

    clearTimers();
    countEl.textContent = "";
    stageEl.replaceChildren();
    stageEl.hidden = false;
    root.dataset.screen = "reveal";

    const done = el("button", "stp-done", "Klaar");
    done.type = "button";
    done.dataset.action = "done";
    const reveal = buildReveal(pack);
    stageEl.append(buildTunnel(), reveal, done, skipButton());
    setPhase("walk");

    const step = 3000;
    let at = step;
    later(() => setPhase("vak"), at);
    at += step;
    later(() => setPhase("weging"), at);
    at += step;
    later(() => {
      setPhase("grade");
      playCount(reveal.querySelector('[data-step="grade"]'), pack, () => setPhase("details"));
    }, at);
  }

  function finishReveal() {
    if (!revealing) return;
    revealing = false;
    clearTimers();
    stageEl.className = "stp-stage";
    stageEl.dataset.phase = "";
    stageEl.hidden = true;
    stageEl.replaceChildren();
    render();
  }

  const initialRequest = ++requestId;
  Promise.all([
    loadOpened().catch(() => []),
    (loadArt ? loadArt() : Promise.resolve(null)).catch(() => null),
  ]).then(([ids, art]) => {
    artState = normalizeArt(art);
    artReady = true;
    if (initialRequest !== requestId) {
      render();
      return;
    }
    opened = new Set((ids || []).map(String));
    loaded = true;
    render();
  });

  return {
    setEnabled(value) {
      const next = value !== false;
      if (enabled === next) return;
      enabled = next;
      if (!next) {
        revealing = false;
        clearTimers();
      }
      render();
    },
    setOnCijfers(value) {
      const next = Boolean(value);
      if (!next) dismissed = false;
      const same = onCijfers === next && host?.isConnected;
      onCijfers = next;
      if (next && !bothSeen() && !loadTimer) {
        loadTimer = setTimeout(() => {
          timedOut = true;
          render();
        }, 4000);
      }
      if (!next && loadTimer) {
        clearTimeout(loadTimer);
        loadTimer = null;
      }
      if (same) return;
      render();
    },
    addResults(endpoint, items) {
      if (endpoint !== "voortgang" && endpoint !== "examen") return;
      byEndpoint[endpoint] = Array.isArray(items) ? items : [];
      seen[endpoint] = true;
      packs = mergedPacks();
      if (!bothSeen()) {
        clearTimeout(loadTimer);
        loadTimer = setTimeout(() => {
          timedOut = true;
          render();
        }, 2500);
      } else {
        clearTimeout(loadTimer);
      }
      render();
    },
    syncOpened(ids) {
      const next = new Set((ids || []).map(String));
      if (loaded && sameSet(opened, next)) return;
      requestId += 1;
      opened = next;
      loaded = true;
      if (!revealing) render();
    },
    showScene(raw, phase) {
      const pack = raw?.id && raw?.resultaat ? raw : normalizeResult(raw);
      if (!pack) return;
      clearTimers();
      revealing = true;
      countEl.textContent = "";
      stageEl.replaceChildren();
      stageEl.hidden = false;
      root.dataset.screen = "reveal";
      const done = el("button", "stp-done", "Klaar");
      done.type = "button";
      done.dataset.action = "done";
      stageEl.append(buildTunnel(), buildReveal(pack), done, skipButton());
      setPhase(phase === "details" ? "details" : "walk");
    },
    applyExternalOpened(ids) {
      requestId += 1;
      opened = new Set((ids || []).map(String));
      loaded = true;
      dismissed = false;
      revealing = false;
      clearTimers();
      render();
    },
    undismiss() {
      dismissed = false;
      render();
    },
  };
}

globalThis.SomtodayPack = { createPackScreen, normalizeResult };
})();
