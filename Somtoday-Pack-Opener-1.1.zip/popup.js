const status = document.getElementById("status");
const connection = document.getElementById("connection");
const reset = document.getElementById("reset");
const toggle = document.getElementById("toggle");

function describe(ids) {
  const count = Array.isArray(ids) ? ids.length : 0;
  if (count === 0) return "Nog geen packs geopend.";
  if (count === 1) return "1 geopend pack onthouden.";
  return `${count} geopende packs onthouden.`;
}

async function refresh() {
  const data = await chrome.storage.local.get(["openedPackIds", "overlayEnabled"]);
  status.textContent = describe(data.openedPackIds);
  const overlayOn = data.overlayEnabled !== false;
  toggle.textContent = overlayOn ? "Cijferpopup uitzetten" : "Cijferpopup aanzetten";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const onSomtoday = Boolean(tab?.url && tab.url.startsWith("https://leerling.somtoday.nl/"));
  if (!onSomtoday) {
    connection.textContext = "Open leerling.somtoday.nl en ververs die pagina.";
    return;
  }
  try {
    const reply = await chrome.tabs.sendMessage(tab.id, { type: "ping" });
    connection.textContent = reply?.ok
      ? "Actief op deze pagina."
      : "Script niet actief. Ververs Somtoday met F5.";
  } catch {
    connection.textContent = "Script niet actief. Ververs Somtoday met F5.";
  }
}

reset.addEventListener("click", async () => {
  reset.disabled = true;
  await chrome.storage.local.set({
    openedPackIds: [],
    packsResetAt: Date.now(),
  });
  status.textContent = "Alle packs zijn gereset.";
  reset.disabled = false;
});

toggle.addEventListener("click", async () => {
  toggle.disabled = true;
  const data = await chrome.storage.local.get("overlayEnabled");
  await chrome.storage.local.set({ overlayEnabled: data.overlayEnabled === false });
  toggle.disabled = false;
  refresh();
});

refresh();
